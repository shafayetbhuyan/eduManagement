python code_generator.py -profile prism-db/cbrms/cbrms.json -e '{"generated_by": "zubair"}' -a generate -up -uv
