#!/usr/bin/env bash

#/Users/HZ/virtualenvs/codegen/bin/python code_generator.py -profile /Users/HZ/ownCloud/prism-db/organization/org.json -a generate -e "{\"generated_by\": \"Palash\"}"


$PROFILE_DIR = /Users/HZ/ownCloud/prism-db/
$USER = zubair
$PYTHON = python

# $PARAMS

$PYTHON code_generator.py -profile $PROFILE_DIR/organization/org.json -a generate -e "{\"generated_by\": \"$USER\"}"

