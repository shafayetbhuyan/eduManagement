## user configuration
CODE_GEN_DIRECTORY = '/Volumes/Work/code-generator/'
TEMPLATE_DIRECTORY = CODE_GEN_DIRECTORY #+ 'templates/'
BASE_OUTPUT_DIR = CODE_GEN_DIRECTORY

PROFILE_DIR = '.'
USER = 'zubair'

## application configuration
profile_dict = {
    'plan': '/project_management/plan.json',
    'clan': '/project_management/plan.json'
}



## generic code for calling code generator
import argparse
import sys
import logging


def main():

    logger = logging.getLogger('Generator')
    logging.basicConfig()

    try:
        sys.path.append(CODE_GEN_DIRECTORY)
        import code_generator
    except ImportError, e:
        logger.error('Code Generator Directory is not defined properly')
        return

    try:
        parser = argparse.ArgumentParser("Code Generator")

        parser.add_argument('profile', help="Select a profile from available profiles", default=None)
        parser.add_argument('action', help="Action to perform [generate, show_tables, show_tables_with_columns]", default='generate')

        args, unknown = parser.parse_known_args()

        profile = profile_dict.get(args.profile)
        action = args.action

        if profile is None:
            logger.error('Profile not found. Available profiles are: %s' % ('"' + '","'.join(profile_dict.keys()) + '"'))
            return

        args = unknown + [
            '--base_template_dir', CODE_GEN_DIRECTORY,
            '--base_db_dir', TEMPLATE_DIRECTORY,
            '--base_output_dir', BASE_OUTPUT_DIR,
            '-profile', PROFILE_DIR + profile,
            '-a', action,
            '-e', '{\"generated_by\": "' + USER + '"}'
        ]
        # print args
        code_generator.main(args)
    except Exception, e:
        raise

# $PARAMS
# $PYTHON code_generator.py -profile $PROFILE_DIR/organization/org.json -a generate -e "{\"generated_by\": \"$USER\"}"


if __name__ == '__main__':
    main()