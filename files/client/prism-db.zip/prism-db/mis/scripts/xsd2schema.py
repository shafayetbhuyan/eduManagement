from collections import OrderedDict
import tabulate
import logging

from lxml import etree

namespaces = {"xs": "http://www.w3.org/2001/XMLSchema"}
logging.basicConfig(level=logging.INFO)

class XsdMetadataGenerator(object):

    logging.getLogger(__name__)

    table_defn = OrderedDict()

    class_defn = OrderedDict()
    ENUMERATION = OrderedDict()
    relation_count = {}
    common_defn = OrderedDict()

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def parseComplex(self, element, className, indent, hasComplexDefn, defn):
        sequences = hasComplexDefn.xpath('./xs:sequence', namespaces=namespaces)

        if len(sequences) == 1:
            maxOccurs = sequences[0].get('maxOccurs')
            if maxOccurs is not None: defn['maxOccurs'] = maxOccurs

            minOccurs = sequences[0].get('maxOccurs')
            if minOccurs is not None: defn['minOccurs'] = minOccurs


            children = sequences[0].getchildren()

            if len(children) == 1:
                childDefn = self.parseElement(children[0], 'Temp', indent)
                defn['subtype'] = childDefn['type']
                if childDefn.get('minOccurs') != None and defn.get('minOccurs') is None:
                    defn['minOccurs'] = childDefn['minOccurs']
            else:
                self.parseClass(sequences[0], defn['elementName'], indent + 4)
                defn['subtype'] = defn['elementName']
        # else:
        #     raise Exception("multiple sequence node type definition found")

    def parseClass(self, root, className, indent, carriedDefn = {}):
        if className not in self.class_defn:
            self.class_defn[className] = []

        self.logger.debug('Processing Table %s', className)

        elements = root.xpath("./xs:element", namespaces=namespaces)
        for each in elements:
            defn = self.parseElement(each, className, indent)

            if defn.get('minOccurs') is None and carriedDefn.get('minOccurs') is not None:
                defn['minOccurs'] = carriedDefn.get('minOccurs')

            if defn.get('maxOccurs') is None and carriedDefn.get('maxOccurs') is not None:
                defn['maxOccurs'] = carriedDefn.get('maxOccurs')

            # print defn
            self.class_defn[className].append(defn)


        choice = root.xpath("./xs:choice", namespaces=namespaces)
        for each in choice:
            self.parseClass(each, className, indent)

        sequences = root.xpath("./xs:sequence", namespaces=namespaces)
        for each in sequences:
            carriedDefn = OrderedDict()
            carriedDefn['minOccurs'] = each.get('minOccurs')
            carriedDefn['maxOccurs'] = each.get('maxOccurs')
            self.parseClass(each, className, indent, carriedDefn)

        complexTypes = root.xpath("./xs:complexType", namespaces=namespaces)
        for each in complexTypes:
            newClassName = each.get('name')
            defn = OrderedDict()
            defn['elementName'] = newClassName
            self.parseComplex(each, newClassName, indent, each, defn)

        simpleTypes = root.xpath("./xs:simpleType", namespaces=namespaces)
        for each in simpleTypes:
            newSimpleTypeName = each.get('name')
            #
            # if 'COMMON' not in self.class_defn:
            #     self.class_defn['COMMON'] = []

            defn = OrderedDict()
            defn['elementName'] = newSimpleTypeName

            self.processSimpleType(newSimpleTypeName, each, defn)

            self.common_defn[newSimpleTypeName] = defn

        # pass


    def processSimpleType(self, elementName, simpleNode, defn):

        restrictions = simpleNode.xpath('./xs:restriction', namespaces=namespaces)
        baseType = restrictions[0].get('base')
        if baseType != None: defn['type'] = baseType

        for r in restrictions[0].getchildren():
            tagName = r.tag.split('}', 1)[1]
            entryName = 'restrictions_' + tagName

            if tagName == 'enumeration':
                if elementName not in self.ENUMERATION:
                    self.ENUMERATION[elementName] = []
                self.ENUMERATION[elementName].append({'code': r.get('value')})
            else:
                defn[entryName] = r.get('value')


    def parseElement(self, element, className, indent):
        elementName = element.get('name')
        minOccurs = element.get('minOccurs')
        maxOccurs = element.get('maxOccurs')
        type = element.get('type')
        nullable = element.get('nillable')

        defn = OrderedDict()
        defn['elementName'] = elementName
        defn['minOccurs'] = minOccurs
        defn['maxOccurs'] = maxOccurs
        defn['nullable'] = nullable
        defn['type'] = type

        hasComplexDefn = None

        if type != None:
            pass
        else:
            complexNodes = element.xpath('./xs:complexType', namespaces=namespaces)
            if len(complexNodes) == 1:
                hasComplexDefn = complexNodes[0]
                defn['type'] = 'ComplexType'
            elif len(complexNodes) > 1:
                raise Exception("multiple complex type definition found")

            simpleNodes = element.xpath('./xs:simpleType', namespaces=namespaces)
            if len(simpleNodes) == 1:
                self.processSimpleType(elementName, simpleNodes[0], defn)
            elif len(complexNodes) > 1:
                raise Exception("multiple simple node type definition found")

        self.logger.debug('Processing Element: %s %s %s %s %s', ' ' * indent, elementName, minOccurs, type, nullable)

        if hasComplexDefn is not None:
            self.parseComplex(hasComplexDefn, className, indent, hasComplexDefn, defn)

        return defn


    def print_classes(self):
        for name, members in self.class_defn.iteritems():
            headers = {
                'Name': 'elementName',
                'Type': 'type',
                'Min': 'minOccurs',
                'Max': 'maxOccurs',
                'Null?': 'nullable'
            }

            print ""
            print name
            print tabulate.tabulate(members, headers=headers, tablefmt="simple")

        print len(self.class_defn)

    def print_tables(self):
        for name, members in self.table_defn.iteritems():
            headers = {
                'Name': 'elementName',
                'Type': 'type',
                'Min': 'minOccurs',
                'Max': 'maxOccurs',
                'Null?': 'nullable'
            }

            print ""
            print name
            print tabulate.tabulate(members, headers=headers, tablefmt="simple")

        print len(self.table_defn)

    def print_enumeration(self):
        for name, enum in self.ENUMERATION.iteritems():
            print ""
            print name
            print tabulate.tabulate(enum, tablefmt="simple")

    def print_common_defn(self):
        print ''
        print tabulate.tabulate(self.common_defn.values(), headers={'elementName': 'Common Simple Elements', 'type': 'Type'}, tablefmt="simple")

    def readFile(self, filename):
        with open(filename, 'r') as fp:
            xsdstr = fp.read()

            # print xsdstr
            doc = etree.fromstring(xsdstr.strip())


            root = doc.xpath("/xs:schema", namespaces=namespaces)
            self.parseClass(root[0], 'AMLReport', 0)
            # elements = doc.xpath("//xs:schema/xs:element", namespaces=namespaces)

    def process(self):
        for table_name, columns in self.class_defn.iteritems():
            for column in columns:
                self._processMember(table_name, column)

    def _processMember(self, className, member):
        # if 'elementName' not in column:
        #     print 'xyz'
        self.logger.debug('Processing Column - %s: %s', className, member['elementName'])

        type = member.get('type')
        if type is None or type == '':
            self.logger.error('Column %s:%s does not have a type', className, member['elementName'])
            type = 'xs:boolean'
            member['type'] = type
            # raise Exception("Cannot process Column")

        if member.get('maxOccurs') is not None:
            member['isList'] = True


    def processRelationCount(self):
        for className, members in self.class_defn.iteritems():
            for each in members:
                type = each.get('type')
                if type is None:
                    print className, each

                if type == 'ComplexType' or not type.startswith('xs:'):
                    type = each.get('type')
                    if each.get('type') in self.relation_count:
                        self.relation_count[type] += 1
                    else:
                        self.relation_count[type] = 1

        print 'Relation Count'
        print tabulate.tabulate(sorted(self.relation_count.items()), tablefmt="simple")

    def _processColumn(self, className, member, column):
        column['name'] = member.get('elementName')
        type = member.get('type')
        if type is None or type == '':
            raise Exception("Cannot process Column")

        xsTypeMap = {
            'xs:boolean': 'BOOLEAN',
            'xs:int': 'INTEGER',
            'xs:string': 'VARCHAR2',
            'xs:decimal': 'DECIMAL',
            'xs:dateTime': 'DATETIME',
            'sql_date': 'DATETIME'
        }

        column['size'] = ''

        classDataType = None
        if type.startswith('xs:') or type == 'sql_date':
            classDataType = type
            if type == 'xs:string':
                column['size'] = member.get('restrictions_maxLength')
        elif type == 'ComplexType':
            column['appName'] = 'mis'
            column['relationalTable'] = self.getTableNameFromClassName(member.get('subtype'))
            column['relationName'] = column['name']
            column['name'] = column['name'] + '_id'
            column['type'] = 'INTEGER'
        elif type in self.class_defn:
            column['appName'] = 'mis'
            column['relationalTable'] = self.getTableNameFromClassName(type)
            column['relationName'] = column['name']
            column['name'] = column['name'] + '_id'
            column['type'] = 'INTEGER'
        elif self.common_defn.get(type):
            commonDefn = self.common_defn.get(type)
            classDataType = commonDefn.get('type')


        if classDataType is None: return

        if classDataType not in xsTypeMap:
            raise Exception('Type "%s"not found in xsTypeMap' % classDataType)

        column['type'] = xsTypeMap[classDataType]


    def getTableNameFromClassName(self, className):
        tableName = 'MIS_' + className.upper()
        return tableName

    def getFinalClassList(self):
        classesToRemove = {}

        finalClassList = []
        for className in self.class_defn.keys():
            if 'registration' in className and className.startswith('t_'):
                classesToRemove[className] = None
            if 'my_client' in className:
                classesToRemove[className[:-len('_my_client')]] = None

            finalClassList.append(className)

        for each in classesToRemove.keys():
            finalClassList.remove(each)

        return finalClassList, classesToRemove

    def convertClassToTable(self):
        self.table_defn = OrderedDict()
        self.processRelationCount()

        count = 0

        finalClassList, skippedClasses = self.getFinalClassList()

        for className in finalClassList:

            members = self.class_defn.get(className)
            self.logger.info('Processing: %s', className)

            tableName = self.getTableNameFromClassName(className)

            column_list = []

            self.table_defn[tableName] = column_list
            primaryKey = OrderedDict()
            primaryKey['name']      = 'id'
            primaryKey['type']      = 'INTEGER'
            primaryKey['size']      = ''
            primaryKey['primary']   = 1
            primaryKey['unique']    = 1
            primaryKey['not_null']  = 1
            primaryKey['isMany']    = ''

            column_list.append(primaryKey)

            for each in members:
                name = each.get('elementName')
                type = each.get('type')
                isList = each.get('isList')

                if name == 'ID': continue
                if type in skippedClasses: continue

                if isList:
                    count += 1

                    column = OrderedDict()
                    column['name'] = each.get('elementName')

                    if type == 'ComplexType':
                        column['type'] = 'LIST: ' + each.get('subtype', '?')
                        pass
                    else:
                        column['type'] = 'LIST: ' + type
                        pass
                    column_list.append(column)

                elif type == 'ComplexType':
                    column = OrderedDict()
                    self._processColumn(className, each, column)
                    column_list.append(column)
                else:
                    column = OrderedDict()
                    self._processColumn(className, each, column)
                    column_list.append(column)

        print '**' * 10, count

    def exportTableDefnToCsv(self):

        import csv

        outputRows = []
        for tableName, member in self.table_defn.iteritems():
            tableRow = [tableName, 'TABLE']
            outputRows.append(tableRow)
            outputRows += [each.values() for each in member]
            outputRows.append([])
            outputRows.append([])

        with open('mis.csv', 'wb') as csvfile:
            spamwriter = csv.writer(csvfile)

            for row in outputRows:
                spamwriter.writerow(row)


if __name__ == '__main__':
    xsdfile = 'goAMLSchema-4.0.xsd'
    generator = XsdMetadataGenerator()
    generator.readFile(xsdfile)
    generator.process()
    generator.convertClassToTable()
    # generator.print_common_defn()
    generator.print_classes()
    generator.print_tables()
    generator.exportTableDefnToCsv()
    # generator.print_enumeration()
