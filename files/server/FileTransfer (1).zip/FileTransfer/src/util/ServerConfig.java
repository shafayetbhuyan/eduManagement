package util;

public class ServerConfig {

    public static Integer port = 4045;
    public static String serverFileDirectory = "E:\\FileTransfer\\files\\server";
}
