package util;

public class ClientConfig {

    public static String host = "127.0.0.1";
    public static Integer port = 4045;
    public static String filetoSendPath = "E:\\FileTransfer\\files\\client\\FileTransfer.zip";
}
