package client;

import util.ClientConfig;
import util.SocketUtil;

import java.net.Socket;

public class client {

    public static void main(String[] args) throws Exception {

        Socket socket = new Socket(ClientConfig.host, ClientConfig.port);
        SocketUtil socketUtil = new SocketUtil(socket);
        new ReadThreadClient(socketUtil);
        new WriteThreadClient(socketUtil);
    }

}
