package client;

import util.ClientConfig;
import util.SocketUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class WriteThreadClient implements Runnable {

    SocketUtil socketUtil;
    Thread t;

    public WriteThreadClient(SocketUtil socketUtil){
        this.socketUtil = socketUtil;
        this.t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        while (true){
            System.out.println("Enter message for the server: ");
            Scanner scanner = new Scanner(System.in);
            String str = scanner.nextLine();
            try {
                this.socketUtil.writeSocket(str);
                File file = new File(ClientConfig.filetoSendPath);
                FileInputStream fileInputStream = new FileInputStream(file);

                byte[] contentBuffer = new byte[fileInputStream.available()];

                int length;
                fileInputStream.read(contentBuffer);
                fileInputStream.close();
                List<byte[]> byteArrList = new ArrayList<>();
                byteArrList.add(file.getName().getBytes());
                byteArrList.add(contentBuffer);

//                while ((length = fileInputStream.read(buffer)) > 0){
//////                    socketUtil.writeSocket(buffer);
////                }
                socketUtil.writeSocket(byteArrList);


                System.out.println();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
