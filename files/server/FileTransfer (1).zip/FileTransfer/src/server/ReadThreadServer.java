package server;



import util.ServerConfig;
import util.SocketUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

public class ReadThreadServer implements Runnable {

    Thread t;
    SocketUtil socketUtil;

    public ReadThreadServer(SocketUtil socketUtil){
        this.socketUtil = socketUtil;
        this.t = new Thread(this);
        t.start();
    }

    @Override
    public void run(){
        while (true){
//            System.out.println("Client: ");
            try {
                Object obj = this.socketUtil.readSocket();
                try {
                    List<byte[]> byteArrList = (List<byte[]>) obj;
                    String fileName = new String(byteArrList.get(0));
                    File file = new File(ServerConfig.serverFileDirectory + File.separator + fileName);
                    file.createNewFile();

                    FileOutputStream fileOutputStream = new FileOutputStream(file);

                    fileOutputStream.write(byteArrList.get(1));
                    fileOutputStream.close();
                    System.out.println();
                }catch (Exception e){
                    System.out.println("Client: " + obj);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
